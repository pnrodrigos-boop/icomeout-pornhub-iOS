<p align="center">
<img src="/Images/logo.png" width="300">
</p>

iCome Out is an open source project of an unofficial Pornub app for iPhone and iPad, written in Swift with some cool features

## Getting Started

### Prerequisites

- iOS 13.5+
- XCode

### Installation

- Clone the repo
- run `pod install` from the terminal, on the root of the project
- build with XCode on your device

## Features
⚠️ - Adult Content - ⚠️

*some screenshots have been partially censored*

### New Reels section and enanched graphics!
#### You can choose the reels source from the settings
<img src="/Images/IMG_1234123.png" width="250">
⬆️ available in tag 1.3

### PIN protection
<img src="/Images/IMG_0690.PNG" width="250">

### Homepage with a search field for the videos and categories filter 
<img src="/Images/IMG_0691.PNG" width="250"> <img src="/Images/IMG_0692.PNG" width="250">

### List of all stars with details
<img src="/Images/IMG_0694.PNG" width="250"> <img src="/Images/IMG_0696.PNG" width="250"> <img src="/Images/IMG_0697.PNG" width="250">
 
### Save your favourite videos and star to your bookmarks
<img src="/Images/IMG_0693.PNG" width="250">

### Extra features:
- Setup a fake PIN, with this feature if you put your fake PIN on the access screen a simple Pokemon list will appear, just for your privacy ;)
- Change the App Icon to hide the app better
- FaceID/TouchID authentication

## Authors

* 🤫

## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details

##### Known issues
- Sometimes the video preview does not load correctly, just close and reopen the preview
- Sometimes the app crash on loading Stars list
