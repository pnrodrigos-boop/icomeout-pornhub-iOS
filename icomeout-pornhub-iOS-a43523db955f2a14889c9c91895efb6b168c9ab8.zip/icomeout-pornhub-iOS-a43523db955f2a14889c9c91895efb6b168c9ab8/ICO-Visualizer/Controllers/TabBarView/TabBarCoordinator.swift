//
//  TabBarCoordinator.swift
//  ICO-visualizer
//
//  Created by Anonymous on 24/09/21.
//

import Foundation

class TabBarCoordinator {

}
